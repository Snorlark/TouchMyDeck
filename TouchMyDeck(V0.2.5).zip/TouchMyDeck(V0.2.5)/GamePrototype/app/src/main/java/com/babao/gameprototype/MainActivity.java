package com.babao.gameprototype;

import android.content.Intent;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import android.util.Log;
import android.os.Vibrator;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Collections;

public class MainActivity extends AppCompatActivity {

    ImageView cardImageView, nextCardImageView;
    Button pokerButton, jokerButton;
    TextView livesTextView, timerTextView, scoreTextView, stacksLeftTextView;
    ArrayList<Integer> cards;
    Handler handler;

    int currentCardIndex = 0;
    int remainingCards;
    int lives = 3;
    int score = 0;
    boolean isCountdownActive = true;
    CountDownTimer timer;
    Animation jokerAnimation, pokerAnimation;

    // Firebase
    FirebaseDatabase database;
    DatabaseReference reference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize FirebaseAuth and DatabaseReference
        database = FirebaseDatabase.getInstance();
        reference = database.getReference("Players");

        // Initialize views
        cardImageView = findViewById(R.id.cardImageView);
        pokerButton = findViewById(R.id.pokerButton);
        jokerButton = findViewById(R.id.jokerButton);
        livesTextView = findViewById(R.id.livesTextView);
        timerTextView = findViewById(R.id.timerTextView);
        scoreTextView = findViewById(R.id.scoreTextView);
        stacksLeftTextView = findViewById(R.id.stacksLeftTextView);

        // Check if the username is provided
        String username = getIntent().getStringExtra("username");
        if (username != null) {
            // Username is provided, no need to handle login again
            // You can proceed with the rest of your MainActivity initialization
        } else {
            // Username is not provided, handle the login process
            // For example, you can start the LoginActivity to get the username
        }

        cards = new ArrayList<>();
        for (int i = 0; i < 15; i++) { // 15 poker cards
            cards.add(R.drawable.poker);
        }
        for (int i = 0; i < 15; i++) { // 15 joker cards
            cards.add(R.drawable.joker);
        }

        Collections.shuffle(cards); //To randomize the cards in the deck

        jokerAnimation = AnimationUtils.loadAnimation(this, R.anim.joker_animation);
        pokerAnimation = AnimationUtils.loadAnimation(this, R.anim.poker_animation);

        updateLives();
        updateScore();
        countdown();

        updateCard();
        updateStacksLeft();

        pokerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Check if buttons can be clicked (not during countdown or game over)
                if (!isCountdownActive) {
                    checkButton(false);
                }
            }
        });

        jokerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Check if buttons can be clicked (not during countdown or game over)
                if (!isCountdownActive) {
                    checkButton(true);
                }
            }
        });
    }


    private void checkButton(boolean isJoker) {
        if ((isJoker && cards.get(currentCardIndex) == R.drawable.joker) || (!isJoker && cards.get(currentCardIndex) == R.drawable.poker)) {
            Toast.makeText(MainActivity.this, "Correct!", Toast.LENGTH_SHORT).show();
            score += 10;
            updateScore(); // Updates score when pressed the correct button
//            updateScoreAndLivesInDatabase(score, lives); // Update score and lives in Firebase database
            cardImageView.startAnimation(isJoker ? jokerAnimation : pokerAnimation); //Animation if joker/poker
            currentCardIndex++; // Moves to the next card
            updateStacksLeft(); // Update the number of stacks left
        } else {
            lives--; //Decrement one life
            updateLives();
            Toast.makeText(MainActivity.this, "Incorrect! Lives remaining: " + lives, Toast.LENGTH_SHORT).show();

            vibrate();

            if (lives == 0 || currentCardIndex == cards.size() - 1) {
                endGame();
                return;
            }
        }
        if (currentCardIndex < cards.size()) {
            updateCard(); // Update the displayed card
        } else {
            endGame();
        }
//        Update score and lives in Firebase database after each button click
//        updateScoreAndLivesInDatabase(score, lives);
    }

    private void vibrate() {
        // Get the vibrator service
        Vibrator vibrator = (Vibrator) getSystemService(VIBRATOR_SERVICE);

        // Check if the device has a vibrator
        if (vibrator != null && vibrator.hasVibrator()) {
            // Vibrate for 500 milliseconds
            vibrator.vibrate(500);
        }
    }

    private void updateCard() {
        handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                cardImageView.setImageResource(cards.get(currentCardIndex));
            }
        }, 400);
    }

    private void updateStacksLeft() {
        int remainingCards = (cards.size() - currentCardIndex); // Decrement one card in the stack
        stacksLeftTextView.setText("Stacks left: " + remainingCards);

        if (remainingCards == 0) {
            endGame();
        }
    }


    private void updateLives() {
        livesTextView.setText("Lives: " + lives);
    }

    private void updateScore() {
        scoreTextView.setText("Score: " + score);
    }


    //Timer for the game

    private void countdown() {
        timerTextView.setText("Time: 3");

        handler = new Handler();
        handler.postDelayed(new Runnable() {
            int countdownSeconds = 3;

            @Override
            public void run() {
                if (countdownSeconds > 0) {
                    timerTextView.setText("Time: " + countdownSeconds);
                    countdownSeconds--;
                    handler.postDelayed(this, 1000);
                } else {
                    isCountdownActive = false; // Countdown has ended, buttons can be clicked
                    startGameTimer();
                }
            }
        }, 1000);
    }

    // Start the actual game timer
    private void startGameTimer() {
        timer = new CountDownTimer(30000, 1000) {
            @Override
            public void onTick(long millisUntilFinished) {
                timerTextView.setText("Time: " + millisUntilFinished / 1000);
            }

            @Override
            public void onFinish() {
                endGame();
            }
        }.start();
    }

    //To end the game
    private void endGame() {
        // Display congratulatory message or game over message
        pokerButton.setEnabled(false);
        jokerButton.setEnabled(false);

        // Cancel the game timer
        if (timer != null) {
            timer.cancel();
        }

        if (score == 300) {
            Toast.makeText(MainActivity.this, "Congratulations! You've won the game with a perfect score of 300 points!", Toast.LENGTH_LONG).show();
        } else {
            Toast.makeText(MainActivity.this, "Game Over! Your score: " + score, Toast.LENGTH_LONG).show();
        }

        // Update score and lives in Firebase database
        updateScoreAndLivesInDatabase(score, lives);

        // Delay for 10 seconds before moving to the next activity
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                startLeaderboardsActivity();
            }
        }, 5000);
    }


    // Start the leaderboards activity



    //To reset the game
    private void resetGame() {
        // Retrieve the highest score and remaining lives passed from LeaderboardsActivity
        int highestScore = getIntent().getIntExtra("highestScore", 0);
        int remainingLives = getIntent().getIntExtra("remainingLives", 3);

        pokerButton.setEnabled(true);
        jokerButton.setEnabled(true);
        currentCardIndex = 0;

        lives = remainingLives;
        score = highestScore;

        updateLives();
        updateScore();
        countdown();
        Collections.shuffle(cards);
        updateCard();
        updateStacksLeft();
    }
    private void startLeaderboardsActivity() {
        Intent intent = new Intent(MainActivity.this, LeaderboardsActivity.class);
        String username = getIntent().getStringExtra("username");
        Log.d("MainActivity", "Username passed to LeaderboardsActivity: " + username);
        intent.putExtra("score", score);
        intent.putExtra("username", getIntent().getStringExtra("username")); // Pass the username to LeaderboardsActivity
        startActivity(intent);
        finish(); // Optional: finish the current activity
    }

    private void updateScoreAndLivesInDatabase(final int newScore, final int newLives) {
        String username = getIntent().getStringExtra("username");
        if (username != null) {
            final DatabaseReference userRef = reference.child(username);

            userRef.addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    if (dataSnapshot.exists()) {
                        // Get the existing score and lives from the database
                        int currentScore = dataSnapshot.child("score").getValue(Integer.class);
                        int currentLives = dataSnapshot.child("lives").getValue(Integer.class);

                        // Check if the new score is equal to the existing score
                        if (newScore == currentScore) {
                            // Check if the new lives is higher than the existing lives
                            if (newLives > currentLives) {
                                // Update the lives in the database
                                userRef.child("lives").setValue(newLives);
                                Toast.makeText(MainActivity.this, "Lives updated successfully!", Toast.LENGTH_SHORT).show();
                            }
                        } else if (newScore > currentScore) {
                            // Update the score and lives in the database
                            userRef.child("score").setValue(newScore);
                            userRef.child("lives").setValue(newLives);
                            Toast.makeText(MainActivity.this, "Score and lives updated successfully!", Toast.LENGTH_SHORT).show();
                        }
                    } else {
                        // If the user data doesn't exist, create new data with the new score and lives
                        userRef.child("score").setValue(newScore);
                        userRef.child("lives").setValue(newLives);
                        Toast.makeText(MainActivity.this, "Score and lives saved for the first time!", Toast.LENGTH_SHORT).show();
                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {
                    Toast.makeText(MainActivity.this, "Failed to update score and lives: " + databaseError.getMessage(), Toast.LENGTH_SHORT).show();
                }
            });
        }

    }

}


// Method to update score in Firebase database
//    private void updateScoreInDatabase(int newScore) {
//        // Get the logged-in username from the intent
//        String username = getIntent().getStringExtra("username");
//        if (username != null) {
//            // Get a reference to the database node where you want to store the score for the logged-in user
//            DatabaseReference userRef = reference.child(username);
//
//            // Set the new score value in the database
//            userRef.child("score").setValue(newScore)
//                    .addOnSuccessListener(new OnSuccessListener<Void>() {
//                        @Override
//                        public void onSuccess(Void aVoid) {
//                            // Score updated successfully
//                            Toast.makeText(MainActivity.this, "Score updated successfully!", Toast.LENGTH_SHORT).show();
//                        }
//                    })
//                    .addOnFailureListener(new OnFailureListener() {
//                        @Override
//                        public void onFailure(@NonNull Exception e) {
//                            // Score update failed
//                            Toast.makeText(MainActivity.this, "Failed to update score: " + e.getMessage(), Toast.LENGTH_SHORT).show();
//                        }
//                    });
//        }
//    }
