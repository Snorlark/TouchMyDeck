package com.babao.gameprototype;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import android.widget.Toast;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class LeaderboardsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_leaderboards);

        int score = getIntent().getIntExtra("score", 0);

        TextView scoreTextView = findViewById(R.id.leaderboards_scoreTextView);
        scoreTextView.setText("Your Score: " + score);

        displayPlaces();

        Button tryAgainButton = findViewById(R.id.tryAgainButton);
        tryAgainButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username = getIntent().getStringExtra("username");
                if (username != null) {
                    Intent intent = new Intent(LeaderboardsActivity.this, MainActivity.class);
                    intent.putExtra("username", username); // Pass the username to MainActivity
                    startActivity(intent);
                    finish();
                } else {
                    // Handle the case where username is null
                    // Display an error message informing the user to try again
                    Toast.makeText(LeaderboardsActivity.this, "Error: Username not found. Please try again.", Toast.LENGTH_SHORT).show();
                }
            }
        });

        Button quitButton = findViewById(R.id.quitButton);
        quitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    private void displayPlaces() {
        DatabaseReference playersRef = FirebaseDatabase.getInstance().getReference("Players");

        playersRef.orderByChild("score").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                List<PlayerAttributes> players = new ArrayList<>();

                for (DataSnapshot playerSnapshot : dataSnapshot.getChildren()) {
                    PlayerAttributes player = playerSnapshot.getValue(PlayerAttributes.class);
                    if (player != null) {
                        players.add(player);
                    }
                }

                Collections.sort(players, new Comparator<PlayerAttributes>() {
                    @Override
                    public int compare(PlayerAttributes p1, PlayerAttributes p2) {
                        if (p1.getScore() == p2.getScore()) {
                            // In case scores of players are the same, compare their lives.
                            return p2.getLives() - p1.getLives();
                        } else {
                            return p2.getScore() - p1.getScore();
                        }

                    }
                });

                for (int i = 0; i < Math.min(players.size(), 3); i++) {
                    PlayerAttributes player = players.get(i);
                    displayPlace(i + 1, player.getUsername(), player.getScore(), player.getLives());
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                // Handle errors
            }
        });
    }

    private void displayPlace(int place, String username, int score, int lives) {
        TextView placeTextView, usernameTextView, scoreTextView, livesTextView;
        String placeSuffix;
        switch (place) {
            case 1:
                placeSuffix = "st";
                placeTextView = findViewById(R.id.firstPlaceTextView);
                usernameTextView = findViewById(R.id.firstPlaceUsernameTextView);
                scoreTextView = findViewById(R.id.firstPlaceScoreTextView);
                livesTextView = findViewById(R.id.firstPlaceLivesTextView);
                break;
            case 2:
                placeSuffix = "nd";
                placeTextView = findViewById(R.id.secondPlaceTextView);
                usernameTextView = findViewById(R.id.secondPlaceUsernameTextView);
                scoreTextView = findViewById(R.id.secondPlaceScoreTextView);
                livesTextView = findViewById(R.id.secondPlaceLivesTextView);
                break;
            case 3:
                placeSuffix = "rd";
                placeTextView = findViewById(R.id.thirdPlaceTextView);
                usernameTextView = findViewById(R.id.thirdPlaceUsernameTextView);
                scoreTextView = findViewById(R.id.thirdPlaceScoreTextView);
                livesTextView = findViewById(R.id.thirdPlaceLivesTextView);
                break;
            default:
                return;
        }

        placeTextView.setText(place + placeSuffix +" Place");
        usernameTextView.setText("Username: " + username);
        scoreTextView.setText("Score: " + score);
        livesTextView.setText("Lives Left: " + lives);
    }

}
