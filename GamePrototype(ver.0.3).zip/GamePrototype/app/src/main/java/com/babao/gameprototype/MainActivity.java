package com.babao.gameprototype;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.os.Vibrator;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collections;

public class MainActivity extends AppCompatActivity {

    ImageView cardImageView, nextCardImageView;
    Button pokerButton, jokerButton;
    TextView livesTextView, timerTextView, scoreTextView, stacksLeftTextView;
    ArrayList<Integer> cards;
    Handler handler;

    int currentCardIndex = 0;
    int remainingCards;
    int lives = 3;
    int score = 0;
    CountDownTimer timer;
    Animation jokerAnimation, pokerAnimation, shakeAnimation;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        cardImageView = findViewById(R.id.cardImageView);
        nextCardImageView = findViewById(R.id.nextCardImageView);
        pokerButton = findViewById(R.id.pokerButton);
        jokerButton = findViewById(R.id.jokerButton);
        livesTextView = findViewById(R.id.livesTextView);
        timerTextView = findViewById(R.id.timerTextView);
        scoreTextView = findViewById(R.id.scoreTextView);
        stacksLeftTextView = findViewById(R.id.stacksLeftTextView);

        cards = new ArrayList<>();
        for (int i = 0; i < 15; i++) { // 15 poker cards
            cards.add(R.drawable.poker);
        }
        for (int i = 0; i < 15; i++) { // 15 joker cards
            cards.add(R.drawable.joker);
        }

        Collections.shuffle(cards); //To randomize the cards in the deck

        jokerAnimation = AnimationUtils.loadAnimation(this, R.anim.joker_animation);
        pokerAnimation = AnimationUtils.loadAnimation(this, R.anim.poker_animation);
        shakeAnimation = AnimationUtils.loadAnimation(this, R.anim.shake_animation);

        updateLives();
        updateScore();
        countdown();

        updateCard();
        updateStacksLeft();

        pokerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) { checkButton(false); }
        });

        jokerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) { checkButton(true);}
        });

    }

    private void checkButton(boolean isJoker) {
        if ((isJoker && cards.get(currentCardIndex) == R.drawable.joker) || (!isJoker && cards.get(currentCardIndex) == R.drawable.poker)) {
            Toast.makeText(MainActivity.this, "Correct!", Toast.LENGTH_SHORT).show();
            score += 10;
            updateScore(); // Updates score when pressed the correct button
            updateNextCard(); // Updates the bottom card
            cardImageView.startAnimation(isJoker ? jokerAnimation : pokerAnimation); //Animation if joker/poker
            currentCardIndex++; // Moves to the next card
            updateStacksLeft(); // Update the number of stacks left
        }
        else {
            lives--; //Decrement one life
            updateLives();
            Toast.makeText(MainActivity.this, "Incorrect! Lives remaining: " + lives, Toast.LENGTH_SHORT).show();

            cardImageView.startAnimation(shakeAnimation); //card shakes (shakira shakira) when wrong
            nextCardImageView.startAnimation(shakeAnimation);
            vibrate();

            if (lives == 0 || currentCardIndex == cards.size() - 1) {
                endGame();
                return;
            }
        }
        if (currentCardIndex < cards.size()) {
            updateCard(); // Update the displayed card
        }
        else {
            endGame();
        }

    }

    private void vibrate() {
        // Get the vibrator service
        Vibrator vibrator = (Vibrator) getSystemService(VIBRATOR_SERVICE);

        // Check if the device has a vibrator
        if (vibrator != null && vibrator.hasVibrator()) {
            // Vibrate for 500 milliseconds
            vibrator.vibrate(500);
        }
    }

    private void updateCard() {
        handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                cardImageView.setImageResource(cards.get(currentCardIndex));
            }
        }, 400);
    }

    private void updateNextCard() {
        if (currentCardIndex < cards.size() - 1) {
            int nextCard = cards.get(currentCardIndex + 1);
            nextCardImageView.setImageResource(nextCard);
        }
        else {
            // No more cards remaining
            nextCardImageView.setVisibility(View.GONE);
        }
    }

    private void updateStacksLeft() {
        int remainingCards = (cards.size() - currentCardIndex); // Decrement one card in the stack
        stacksLeftTextView.setText("Stacks left: " + remainingCards);

        if (remainingCards == 0) {
            endGame();
        }
    }


    private void updateLives() {
        livesTextView.setText("Lives: " + lives);
    }

    private void updateScore() {
        scoreTextView.setText("Score: " + score);
    }

    //Timer for the game
    private void countdown() {

        timerTextView.setText("Initial Time: 3"); // Display initial time before starting the timer

        // Adding a countdown of 3 seconds before starting the timer
        handler = new Handler();
        handler.postDelayed(new Runnable() {
            int countdownSeconds = 3;

            @Override
            public void run() {
                if (countdownSeconds > 0) {
                    timerTextView.setText("Initial Time: " + countdownSeconds);
                    countdownSeconds--;
                    handler.postDelayed(this, 1000); // Repeat every 1 second
                } else {
                    startGameTimer(); // Start the actual game timer pagtapos ng countdown
                }
            }
        }, 1000); // 1 second delay before the countdown starts
    }
    // Start the actual game timer
    private void startGameTimer() {
        timer = new CountDownTimer(30000, 1000) {
            @Override
            public void onTick(long millisUntilFinished) {
                timerTextView.setText("Time: " + millisUntilFinished / 1000);
            }

            @Override
            public void onFinish() {
                endGame();
            }
        }.start();
    }

    //To end the game
    private void endGame() {
        timer.cancel();
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Game Over");
        if (score == 300) {
            builder.setMessage("Congratulations! You've won the game with a perfect score of 300 points!");
        }
        else {
            builder.setMessage("Game Over! Your score: " + score + ". Do you want to try again?");
        }
        builder.setPositiveButton("Try Again", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                resetGame();
            }
        });
        builder.setNegativeButton("Quit", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                finish();
            }
        });
        builder.setCancelable(false);
        builder.show();
    }

    //To reset the game
    private void resetGame() {
        currentCardIndex = 0;
        lives = 3;
        score = 0;
        updateLives();
        updateScore();
        countdown();
        Collections.shuffle(cards);
        updateCard();
        updateStacksLeft();
    }
}
