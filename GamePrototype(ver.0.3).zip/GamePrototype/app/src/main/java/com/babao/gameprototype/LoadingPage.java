package com.babao.gameprototype;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;

public class LoadingPage extends AppCompatActivity {

    Animation fadein, fadeout;
    Handler handler;
    ImageView jack_icon;
    Boolean flip = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_loading_page);

        jack_icon = findViewById(R.id.jack_icon);

        fadein = AnimationUtils.loadAnimation(this, R.anim.fade_in_splash);

        jack_icon.setAnimation(fadein);
        startRotationAnimation();

        handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                flip = false;
                handler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        jack_icon.clearAnimation(); // Stop the animation

                        // Start the next activity after stopping the animation
                        Intent i = new Intent(LoadingPage.this, HomeLogActivity.class);
                        startActivity(i);
                        overridePendingTransition(R.anim.fade_in_splash, R.anim.fade_out_splash);
                        finish();
                    }
                }, 1000);
            }
        }, 3000);
    }

    private void startRotationAnimation() {
        jack_icon.animate().rotationY(360f).setDuration(1500) // Set initial flip
                .setInterpolator(AnimationUtils.loadInterpolator(LoadingPage.this, android.R.anim.linear_interpolator))
                .setStartDelay(0)
                .withEndAction(new Runnable() {
                    @Override
                    public void run() {

                        if (flip) {
                            // Reset rotation to 0 degrees
                            jack_icon.setRotationY(0f);

                            // Start the next flip immediately
                            startRotationAnimation();

                        }
                    }
                })
                .start();
    }

}