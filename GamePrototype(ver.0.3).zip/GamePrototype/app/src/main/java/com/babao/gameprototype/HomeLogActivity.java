package com.babao.gameprototype;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RelativeLayout;

import androidx.appcompat.app.AppCompatActivity;

public class HomeLogActivity extends AppCompatActivity {

    private Button buttonLogin, buttonSignUp;

    RelativeLayout splash_title;
    ImageView title_tmd;
    Handler handler;
    Animation fadein, slideup;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.activity_home_log);

        splash_title = findViewById(R.id.splash_title);

        title_tmd = findViewById(R.id.title_tmd);

        buttonLogin = findViewById(R.id.buttonLogin);
        buttonSignUp = findViewById(R.id.buttonSignUp);


        fadein = AnimationUtils.loadAnimation(this, R.anim.fade_in_splash);
        slideup = AnimationUtils.loadAnimation(this, R.anim.slide_out_top);

        title_tmd.setAnimation(fadein);

        handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {

                splash_title.setAnimation(slideup);
                splash_title.setVisibility(View.GONE);

            }
        }, 1500);

        buttonLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(HomeLogActivity.this, LoginActivity.class));
            }
        });

        buttonSignUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(HomeLogActivity.this, SignUpActivity.class));
            }
        });
    }
}