package com.babao.gameprototype;

import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class SignUpActivity extends AppCompatActivity {

    private EditText editTextEmail, editTextNewUsername, editTextNewPassword;
    private Button buttonSignUp, buttonBack;

    FirebaseDatabase database;
    DatabaseReference reference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);

        editTextEmail = findViewById(R.id.editTextEmail);
        editTextNewUsername = findViewById(R.id.editTextNewUsername);
        editTextNewPassword = findViewById(R.id.editTextNewPassword);
        buttonSignUp = findViewById(R.id.buttonSignUp);

        buttonSignUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email = editTextEmail.getText().toString();
                String username = editTextNewUsername.getText().toString();
                String password = editTextNewPassword.getText().toString();

                database = FirebaseDatabase.getInstance();
                reference = database.getReference("Players");

                if (isValid(email, username, password)) {
                    PlayerAttributes identity = new PlayerAttributes(email, username, password);
                    reference.child(username).setValue(identity);

                    Toast.makeText(SignUpActivity.this, "Sign up successful!", Toast.LENGTH_SHORT).show();

                    Intent intent = new Intent(SignUpActivity.this, LoginActivity.class);
                    startActivity(intent);
                    finish();
                } else {

                    Toast.makeText(SignUpActivity.this, "Invalid. Please try again.", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
    private boolean isValid(String email, String username, String password) {
        return email.endsWith("@National-u")&& !username.isEmpty() && !password.isEmpty();
    }
}