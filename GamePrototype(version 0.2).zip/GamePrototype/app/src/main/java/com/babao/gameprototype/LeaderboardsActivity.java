package com.babao.gameprototype;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class LeaderboardsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_leaderboards);

        int score = getIntent().getIntExtra("score", 0);

        TextView scoreTextView = findViewById(R.id.leaderboards_scoreTextView);
        scoreTextView.setText("Your Score: " + score);

        displayPlaces();

        Button tryAgainButton = findViewById(R.id.tryAgainButton);
        tryAgainButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startMainActivity();
            }
        });

        Button quitButton = findViewById(R.id.quitButton);
        quitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    private void startMainActivity() {
        Intent intent = new Intent(LeaderboardsActivity.this, MainActivity.class);
        startActivity(intent);
        finish();
    }

    private void displayPlaces() {
        DatabaseReference playersRef = FirebaseDatabase.getInstance().getReference("Players");

        playersRef.orderByChild("score").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                List<PlayerAttributes> players = new ArrayList<>();

                for (DataSnapshot playerSnapshot : dataSnapshot.getChildren()) {
                    PlayerAttributes player = playerSnapshot.getValue(PlayerAttributes.class);
                    if (player != null) {
                        players.add(player);
                    }
                }

                Collections.sort(players, new Comparator<PlayerAttributes>() {
                    @Override
                    public int compare(PlayerAttributes p1, PlayerAttributes p2) {
                        return p2.getScore() - p1.getScore();
                    }
                });

                for (int i = 0; i < Math.min(players.size(), 3); i++) {
                    PlayerAttributes player = players.get(i);
                    displayPlace(i + 1, player.getUsername(), player.getScore());
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                // Handle errors
            }
        });
    }

    private void displayPlace(int place, String username, int score) {
        TextView placeTextView, usernameTextView, scoreTextView;

        switch (place) {
            case 1:
                placeTextView = findViewById(R.id.firstPlaceTextView);
                usernameTextView = findViewById(R.id.firstPlaceUsernameTextView);
                scoreTextView = findViewById(R.id.firstPlaceScoreTextView);
                break;
            case 2:
                placeTextView = findViewById(R.id.secondPlaceTextView);
                usernameTextView = findViewById(R.id.secondPlaceUsernameTextView);
                scoreTextView = findViewById(R.id.secondPlaceScoreTextView);
                break;
            case 3:
                placeTextView = findViewById(R.id.thirdPlaceTextView);
                usernameTextView = findViewById(R.id.thirdPlaceUsernameTextView);
                scoreTextView = findViewById(R.id.thirdPlaceScoreTextView);
                break;
            default:
                return;
        }

        placeTextView.setText(place + "st Place");
        usernameTextView.setText("Username: " + username);
        scoreTextView.setText("Score: " + score);
    }
}
